package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Main2014302580333 implements IMailService{
	private Properties propertiesS;
	private Properties propertiesI;
	private Session sessionS;
	private Session sessionI;
	private String userName="wudijiefangjun@sina.com";
	private String password="";
	private MailAuthenticator mailAuthenticator;

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		propertiesS=System.getProperties();
		propertiesI=System.getProperties();
		mailAuthenticator=new MailAuthenticator(userName, password);
		//smtp
		propertiesS.put("mail.smtp.auth", "true");
		propertiesS.put("mail.smtp.host", "smtp.sina.com");
		propertiesS.put("mail.transport.protocol", "smtp");
		sessionS=Session.getInstance(propertiesS, mailAuthenticator);
		//imap
        propertiesI.put("mail.imap.auth", "true");
		propertiesI.put("mail.store.protocol", "imap");
		propertiesI.put("mail.imap.host", "imap.sina.com");
		sessionI=Session.getInstance(propertiesI, mailAuthenticator);
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		MimeMessage message=new MimeMessage(sessionS);
		message.setFrom(new InternetAddress(userName));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(),"text/html;charest=UTF-8");
		Transport.send(message);
	}

	@Override
	public boolean listen() throws MessagingException { 
		Store store = sessionI.getStore();
		store.connect();
	    Folder folder =store.getFolder("inbox");
	    folder.open(Folder.READ_ONLY); 
	    if (folder.getNewMessageCount()>0){
	    	return true;
	    }else{
	    	return false;
	    }
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		Store store = sessionI.getStore();
		store.connect();
		Folder folder =store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		Message message=folder.getMessage(folder.getMessageCount());
		return message.getSubject().toString()+message.getContent().toString();//返回主题和内容
		
	}
	

}
