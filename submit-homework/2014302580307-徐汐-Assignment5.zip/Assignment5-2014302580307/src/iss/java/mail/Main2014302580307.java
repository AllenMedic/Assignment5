package iss.java.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeUtility;

import com.sun.mail.imap.IMAPMessage;

public class Main2014302580307 implements IMailService{
	/**
	 * �û���
	 */
	String username = "g6818484@163.com";
	/**
	 * ����
	 */
	String password="ivnsfevjzlagwtdx";
	Properties props=null;
	Session session;
	@Override
	public void connect() throws MessagingException {
		// TODO �Զ����ɵķ������
		 props = new Properties();
		 props.setProperty("mail.transport.protocol", "smtp"); 
	     props.setProperty("mail.smtp.host", "smtp.163.com"); 
	     props.setProperty("mail.smtp.port", "25"); 
	     props.setProperty("mail.smtp.auth", "true"); 
	     props.setProperty("mail.store.protocol", "imap");
	     props.setProperty("mail.imap.host", "imap.163.com");
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO �Զ����ɵķ������
		session = Session.getDefaultInstance(props);
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(username));
		message.setSubject(subject); 
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient)); 
		message.setText((String) content); 
		Transport transport = session.getTransport();
		transport.connect(username, password); 
		transport.sendMessage(message, message.getAllRecipients()); 
		transport.close();
//		Transport ts = session.getTransport();
//		ts.connect("smtp.163.com", username, password);
//		Message msg = new MimeMessage(session);  
//		msg.setFrom(new InternetAddress(recipient));
//		msg.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
//		msg.setSubject(subject);
//		msg.setContent(content, "text/html;charset=UTF-8");
//		ts.sendMessage(msg, msg.getAllRecipients());
//		ts.close();
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO �Զ����ɵķ������
		Store store = session.getStore("imap");  
		store.connect(username, password);  
		Folder folder = store.getFolder("INBOX"); 
		folder.open(Folder.READ_ONLY);
		Message[] messages = folder.getMessages();
		boolean a=true;
		if(messages != null){
			a=true;
		}
		else{
			a=false;
		}
		return a;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO �Զ����ɵķ������
		Store store = session.getStore("imap");  
		store.connect(username, password);  
		Folder folder = store.getFolder("INBOX");  
		folder.open(Folder.READ_WRITE);  
		Message[] messages = folder.getMessages();
		String text = "";
		for(Message message:messages){
			IMAPMessage msg=(IMAPMessage)message;
			String subject1 = msg.getSubject(); 
			if(subject1.equals(subject)){
				text = (String) msg.getContent();
			}
		}
//		for (Message message : messages) {  
//			IMAPMessage msg = (IMAPMessage) message;  
//			String subject1 = MimeUtility.decodeText(msg.getSubject());  
//			System.out.println("[" + subject1 + "]δ�����Ƿ���Ҫ�Ķ����ʼ���yes/no����");  
//			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));  
//			String answer = reader.readLine();  
//		}  
		return text; 
	}

}
